package com.marvis.globalsettings;

import android.database.ContentObserver;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;

import androidx.preference.PreferenceFragmentCompat;
import androidx.preference.SwitchPreferenceCompat;

/**
 * Preference 设置页：两个开关直接读写 Settings.Global。
 * 开启 -> 写入 "true"，关闭 -> 写入 "false"。
 * 通过 ContentObserver 监听 Settings.Global 变化，shell / 系统侧修改后界面自动同步。
 * 应用以 android.uid.system 运行（需 platform 签名），无需任何权限即可写 Global。
 */
public class GlobalSettingsFragment extends PreferenceFragmentCompat {

    private static final String KEY_NVG_HOME = "nvg_home";
    private static final String KEY_STATUS_BAR_QS = "status_bar_qs";

    private final ContentObserver globalObserver = new ContentObserver(
            new Handler(Looper.getMainLooper())) {
        @Override
        public void onChange(boolean selfChange) {
            syncSwitches();
        }
    };

    @Override
    public void onCreatePreferences(Bundle savedInstanceState, String rootKey) {
        setPreferencesFromResource(R.xml.global_settings, rootKey);
        bindSwitch(KEY_NVG_HOME);
        bindSwitch(KEY_STATUS_BAR_QS);
    }

    @Override
    public void onStart() {
        super.onStart();
        requireContext().getContentResolver()
                .registerContentObserver(Settings.Global.CONTENT_URI, true, globalObserver);
        syncSwitches();
    }

    @Override
    public void onStop() {
        requireContext().getContentResolver().unregisterContentObserver(globalObserver);
        super.onStop();
    }

    private void bindSwitch(String key) {
        SwitchPreferenceCompat switchPreference = findPreference(key);
        if (switchPreference == null) {
            return;
        }
        switchPreference.setChecked(readGlobal(key));
        switchPreference.setOnPreferenceChangeListener((preference, newValue) -> {
            boolean enabled = Boolean.TRUE.equals(newValue);
            writeGlobal(key, enabled);
            return true;
        });
    }

    /**
     * 将 UI 开关状态对齐到 Settings.Global 当前值。
     * 仅在实际值不同时才 setChecked，避免无谓刷新。
     */
    private void syncSwitches() {
        syncSwitch(KEY_NVG_HOME);
        syncSwitch(KEY_STATUS_BAR_QS);
    }

    private void syncSwitch(String key) {
        SwitchPreferenceCompat switchPreference = findPreference(key);
        if (switchPreference == null) {
            return;
        }
        boolean current = readGlobal(key);
        if (switchPreference.isChecked() != current) {
            switchPreference.setChecked(current);
        }
    }

    private boolean readGlobal(String key) {
        String value = Settings.Global.getString(requireContext().getContentResolver(), key);
        return "true".equalsIgnoreCase(value) || "1".equals(value);
    }

    private void writeGlobal(String key, boolean enabled) {
        Settings.Global.putString(
                requireContext().getContentResolver(),
                key,
                enabled ? "true" : "false");
    }
}
