package com.rosan.installerxuidemo.preference

import android.graphics.Color
import android.os.Bundle
import android.view.View
import androidx.preference.Preference
import androidx.preference.PreferenceFragmentCompat
import androidx.recyclerview.widget.RecyclerView
import com.rosan.installerxuidemo.R

/**
 * 设置页 Fragment，从 XML 加载 Preference 层级。
 *
 * XML 中通过**全限定类名**引用自定义 Compose Preference：
 * - com.rosan.installerxuidemo.preference.ComposeSwitchPreference
 * - com.rosan.installerxuidemo.preference.ComposePreference
 */
class SettingsFragment : PreferenceFragmentCompat() {

    override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
        setPreferencesFromResource(R.xml.preferences, rootKey)

        findPreference<ComposePreference>(KEY_OPEN_THEME)?.setOnPreferenceClickListener { true }
        findPreference<ComposePreference>(KEY_OPEN_INSTALLER)?.setOnPreferenceClickListener { true }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        // 让 Preference 列表背景透明，透出外层 Compose Scaffold 的 surface 色
        listView?.setBackgroundColor(Color.TRANSPARENT)
        view.setBackgroundColor(Color.TRANSPARENT)
        // 移除 Preference 列表默认的分隔线，粘连卡片不需要分隔线
        (listView as? RecyclerView)?.let { rv ->
            repeat(rv.itemDecorationCount) { rv.removeItemDecorationAt(0) }
        }
    }

    companion object {
        const val KEY_USE_BLUR = "use_blur"
        const val KEY_NOTIFICATION = "notification_install"
        const val KEY_SECURE_MODE = "secure_mode"
        const val KEY_OPEN_THEME = "open_theme"
        const val KEY_OPEN_INSTALLER = "open_installer"
    }
}
